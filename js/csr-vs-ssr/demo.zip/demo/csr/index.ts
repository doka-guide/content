import { app } from "../app";
import { render } from "../render";

render(app, document.querySelector("#csr-root"));
