import { app } from "../app.js";
import { hydrate } from "../hydrate.js";

hydrate(app);
